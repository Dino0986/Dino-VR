Replace your 3dui folder with this one, it should be in C:\Program Files\Janus VR\assets

!!! Keep a backup of this, JanusVR resets the 3dui folder on update !!!